#include <iostream>

using namespace std;

class Restaurant : Public Facility {
	public:
		
	private:
};