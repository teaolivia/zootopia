// driver Animal
#include "animal.h"
#include <iostream>
using namespace std;

int main() {

    Animal a;

    cout << "beratbadan: " << a.getberatBadan() << endl;
    cout << "getnbmakanan: " << a.GetNbMakanan() << endl;

    return 0;
}
