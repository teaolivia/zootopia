#include "Zoo.h"

// 5 sekawan
Zoo::Zoo() : row(x), column(y) {
	Cell **cell = new Cell*[row];
	for (int i=0; i<row; i++) {
		Cell cell[i] = new Cell[column];
		for (int j=0; j<column; j++){

		}
	}
}

Zoo::Zoo(int x, int y) : row(x), column(y){
	Cell **cell = new Cell *[row];
		for (int j=0; j<= row; j++) {
			Cell cell[j] = new Cell [column];
			for (int i=0; i<= column; i++) {
			}
		}
} 

Zoo::Zoo(const Cell& c) : row (c.row), column (c.column) {
	int i,j;
		
		Cell cell = new Cell *[row];
		for (i=0; i<=row; i++) {
			Cell cell[i] = new Cell[column];
			for (j=0; j<=column; j++) {
				cell[j] = c.cell[j];
			}
		}
}

Zoo::~Zoo() {
	//int i,j;
	for (int j=0; j<column; j++) {
		delete [] cell[j];
		for (int i=0; i<row; i++) 
			delete [] cell[i];	
	}
}

Zoo& Zoo::operator=(const Cell& c) {
		delete [] cell;
		cell = new Cell*[row];
		for (int i=0; i<row; i++) {
	        cell[i] = new Cell[column];
	        for (int j=0; j<column; j++) {
	            cell[i][j] = c.cell[i][j];
	        }
		}
		return *this;
}

void Zoo::printZoo() {

}