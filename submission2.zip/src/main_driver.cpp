#include "animal.h"


#include <iostream>
using namespace std;


int main() {

	Animal *c = new Cheetah(2,2);

	Cheetah c(2,2);

	return 0;
}