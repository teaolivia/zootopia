#ifndef CELL_H
#define CELL_H

#include <iostream>

class Matriks;
class Zoo;
/** @class Cell
  * Kelas yang mengandung member sebagai isi cell
  */
class Cell {
	//public:
    //friend class Zoo;
    //friend class Cage;
    //getter setter
  

		//Road<> road;
    // location
};
#endif