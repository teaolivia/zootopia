#include "cage.h"
#include "water.h"
#include "air.h"
#include "land.h"
#include <iostream>

using namespace std;

int main() {
	int x,y;
 	Water w;

 	w.printCage(x,y);

    return 0;
}
