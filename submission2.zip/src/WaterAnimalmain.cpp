
#include "animal.h"
#include "water_animal.h"
#include "Water.h"
#include <iostream>
using namespace std;

int main() {
    WaterAnimal w(100);
    return 0;
}
