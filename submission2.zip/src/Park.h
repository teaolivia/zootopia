#include <iostream>

using namespace std;

class Park : public Facility {
	public:
		
	private:
};