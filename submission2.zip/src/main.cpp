#include <iostream>
#include "animal.h"
#include "zoo.h"

using namespace std;

int main() {
	cout << "Selamat datang di Zootopia <3" << endl;
	cout << "Selamat menjelajah <3" << endl;
	Zoo Z;  //need to generate maps (?)
	Animal A;
	Cage C;
	Zoo();
	return 0;
}